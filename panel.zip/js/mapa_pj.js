

        mapboxgl.accessToken = 'pk.eyJ1Ijoic2llcGoiLCJhIjoiY2xxNW56MHU1MGwxbjJrdDZudWtyeW5qcSJ9.hN84Imb93lgO2kHN7YtxOw';
        const map = new mapboxgl.Map({
            container: 'map',
            //style: 'mapbox://styles/siepj/clq6985of001201pdej8r84sc',
			style: 'mapbox://styles/siepj/clq7ic0sp003801qr3j2pguc7',
			//style: 'mapbox://styles/mapbox/streets-v12',
			//style: 'mapbox://styles/mapbox/light-v11',
			//style: 'mapbox://styles/mapbox/satellite-v9',
			projection: 'globe',
            center: [-75.015152, -9.189967],
            zoom: 2//,
			 //essential: true 
        });
		
	    // Verifica si el tab que se mostró contiene tu mapa
   /* if ($(e.target).attr("href") == "#tab-map") {
        map.resize(); // Reajusta el mapa
    }	*/
	
        const departments = {
		
'AMAZONAS': { 'center': [-79.2417025, -5.1828945], 'zoom': 7.2},
'ANCASH': { 'center': [-78.0114997, -9.6129154], 'zoom': 7.8},
'APURIMAC': { 'center': [-73.6087542, -14.0044984], 'zoom': 8.5},
'AREQUIPA': { 'center': [-73.5317568, -16.0993298], 'zoom': 7.5},
'AYACUCHO': { 'center': [-74.2269566, -14.1597328], 'zoom': 7.3},
'CAJAMARCA': { 'center': [-78.519528, -7.1566287], 'zoom': 8.5},
'CALLAO': { 'center': [-77.144891, -12.0067834], 'zoom': 12},
'CAÑETE': { 'center': [-76.37893, -12.7204076], 'zoom': 8.7},
'CUSCO': { 'center': [-72.0951423, -13.5298041], 'zoom': 7},
'HUANCAVELICA': { 'center': [-74.9749972, -12.9886551], 'zoom': 9},
'HUANUCO': { 'center': [-76.2403164, -9.4288074], 'zoom': 8},
'HUAURA': { 'center': [-77.6109756, -11.1138332], 'zoom': 8.2},
'ICA': { 'center': [-75.7265511, -14.3570295], 'zoom': 7.8},
'JUNIN': { 'center': [-75.2149651, -11.8596076], 'zoom': 8},
'LA LIBERTAD': { 'center': [-79.0486913, -8.1135369], 'zoom': 8},
'LAMBAYEQUE': { 'center': [-79.8456559, -5.8817076], 'zoom': 7.8},
'LIMA ESTE': { 'center': [-76.9532954, -12.0057915], 'zoom': 9.2},
'LIMA NORTE': { 'center': [-77.061657, -11.6589963], 'zoom': 9.3},
'LIMA SUR': { 'center': [-76.9550251, -12.3091775], 'zoom': 10.5},
'LIMA': { 'center': [-77.0310279, -12.1037718], 'zoom': 11.6},
'LORETO': { 'center': [-76.5506889, -4.1938075], 'zoom': 6.2},
'MADRE DE DIOS': { 'center': [-71.1843193, -12.0004532], 'zoom': 7.3},
'MOQUEGUA': { 'center': [-70.9422582, -17.1869334], 'zoom': 8},
'PASCO': { 'center': [-76.2527088, -10.6666256], 'zoom': 9},
'PIURA': { 'center': [-80.626047, -5.5983974], 'zoom': 8},
'PUENTE PIEDRA-VENTANILLA': { 'center': [-77.1262437, -11.7771805], 'zoom': 10.5},
'PUNO': { 'center': [-70.0284253, -15.4409241], 'zoom': 7},
'SAN MARTIN': { 'center': [-76.974594, -6.0339178], 'zoom': 6.5},
'SANTA': { 'center': [-78.5902312, -9.3769284], 'zoom': 7.8},
'SELVA CENTRAL': { 'center': [-75.3296963, -11.0552852], 'zoom': 7.8},
'SULLANA': { 'center': [-80.6864472, -4.8903579], 'zoom': 8},
'TACNA': { 'center': [-70.2536922, -17.6003966], 'zoom': 8.5},
'TUMBES': { 'center': [-80.8304589, -3.8532438], 'zoom': 8.5},
'UCAYALI': { 'center': [-74.5330954, -8.6846123], 'zoom': 6.5},
            // ... otros departamentos con sus coordenadas centrales
        };
		
		
	map.on('style.load', () => {
map.setFog({}); // Set the default atmosphere style
});	
		
		
var todosLosMarcadores = []; 
var marcadoresCreados = false;
        map.on('load', function() {
		
		
		
		
		    setTimeout(function() {
        map.flyTo({
            center: [-75.015152, -9.189967],
            zoom: 5,
            speed: 0.5, // Controla la velocidad de la animación
            curve: 1, // Controla la curva de la animación
            essential: true
        });
    }, 600); // Inicia la animación después de 3 segundos

		
		
            map.addSource('Provincia', {
                'type': 'vector',
                'url': 'mapbox://siepj.0tqct1lo'
            });

            // Agregar una capa (layer) utilizando la fuente añadida
            map.addLayer({
                'id': 'capa_provincia',
                'type': 'fill', // o 'line', 'symbol', 'circle', etc., dependiendo del tipo de capa
                'source': 'Provincia',
                'source-layer': 'prov2021-bcql32', // Reemplaza con el nombre de la capa en el tileset
                'paint': {
                   'fill-color': '#ccc', // Color inicial de la capa
                    'fill-opacity': 0.6
                }
            });		

        map.addLayer({
            'id': 'bordes-provincia',
            'type': 'line',
            'source': 'Provincia', // Asegúrate de que esta sea la fuente correcta
            'source-layer': 'prov2021-bcql32', // Y esta la capa correcta dentro de la fuente
            'layout': {},
            'paint': {
                'line-color': '#B00000', // Color negro para el borde
                'line-width': 1 // Aumentar el ancho del borde
            }
        });			
		
		
            map.addSource('ProvinciaName', {
                'type': 'vector',
                'url': 'mapbox://siepj.18i9jhov'
            });

            // Agregar una capa (layer) utilizando la fuente añadida
map.addLayer({
    'id': 'nombre_prov',
    'type': 'symbol',
    'source': 'ProvinciaName',
    'source-layer': 'PUNTOS_PROV2021-0p1a16',
    'layout': {
        'text-field': [
            'format',
            ['literal', ''], // Texto estático
            {}, // Estilo opcional para el texto estático
            ['get', 'PROVINCIA_'], // Valor dinámico
            {}  // Estilo opcional para el valor dinámico
        ],
        'text-size': 8,
        'text-font': ['Open Sans Bold', 'Arial Unicode MS Bold'] // Ejemplo de tipos de letra
    },
    'paint': {
        'text-color': '#000'//, // Color del texto
       // 'text-halo-color': '#000', // Color del halo (opcional para mejorar la legibilidad)
       // 'text-halo-width': 1 // Ancho del halo (opcional)
    }
});
		
		
// Agregar una fuente (source) basada en un tileset de Mapbox
            map.addSource('Departamento', {
                'type': 'vector',
                'url': 'mapbox://siepj.6u4gdzk7'
            });

            // Agregar una capa (layer) utilizando la fuente añadida
            map.addLayer({
                'id': 'mi-capa',
                'type': 'fill', // o 'line', 'symbol', 'circle', etc., dependiendo del tipo de capa
                'source': 'Departamento',
                'source-layer': 'dj2021-bhvca7', // Reemplaza con el nombre de la capa en el tileset
				'layout': {
                    'visibility': 'visible' // Inicialmente oculta
                },
                'paint': {
				'fill-opacity': 1,
				'fill-color': [
                'match',
                ['get', 'DISTRITO_J'], 
				'AMAZONAS','#B12009',
				'ANCASH','#B12009',
				'APURIMAC','#B12009',
				'AREQUIPA','#B12009',
				'AYACUCHO','#B12009',
				'CAJAMARCA','#B12009',
				'CALLAO','#B12009',
				//'CAÑETE','#B12009',
				'CUSCO','#B12009',
				//'HUANCAVELICA','#B12009',
				//'HUANUCO','#B12009',
				//'HUAURA','#B12009',
				//'ICA','#B12009',
				//'JUNIN','#B12009',
				'LA LIBERTAD','#B12009',
				'LAMBAYEQUE','#B12009',
				//'LIMA ESTE','#B12009',
				//'LIMA NORTE','#B12009',
				//'LIMA SUR','#B12009',
				//'LIMA','#B12009',
				'LORETO','#B12009',
				'MADRE DE DIOS','#B12009',
				'MOQUEGUA','#B12009',
				//'PASCO','#B12009',
				'PIURA','#B12009',
				'PUENTE PIEDRA-VENTANILLA','#B12009',
				'PUNO','#B12009',
				'SAN MARTIN','#B12009',
				'SANTA','#B12009',
				//'SELVA CENTRAL','#B12009',
				'SULLANA','#B12009',
				'TACNA','#B12009',
				'TUMBES','#B12009',
				//'UCAYALI','#B12009',
                
                '#fff' 
            ]
        }
            });	


        map.addLayer({
            'id': 'bordes-departamento',
            'type': 'line',
            'source': 'Departamento', // Asegúrate de que esta sea la fuente correcta
            'source-layer': 'dj2021-bhvca7', // Y esta la capa correcta dentro de la fuente
            'layout': {},
            'paint': {
                'line-color': '#666', // Color negro para el borde
                'line-width': 1 // Aumentar el ancho del borde
            }
        });

// Agregar una fuente (source) basada en un tileset de Mapbox
            map.addSource('DepartamentoName', {
                'type': 'vector',
                'url': 'mapbox://siepj.asn3ij9m'
            });

            // Agregar una capa (layer) utilizando la fuente añadida
map.addLayer({
    'id': 'nombre_dj',
    'type': 'symbol',
    'source': 'DepartamentoName',
    'source-layer': 'DJ_NOMBRES-346gl2',
    'layout': {
        'text-field': [
            'format',
            ['literal', 'CSJ DE '], // Texto estático
            {}, // Estilo opcional para el texto estático
            ['get', 'DISTRITO_J'], // Valor dinámico
            {}  // Estilo opcional para el valor dinámico
        ],
        'text-size': 10,
        'text-font': ['Open Sans Bold', 'Arial Unicode MS Bold'] // Ejemplo de tipos de letra
    },
    'paint': {
        'text-color': '#000', // Color del texto
        'text-halo-color': '#ccc', // Color del halo (opcional para mejorar la legibilidad)
        'text-halo-width': 1 // Ancho del halo (opcional)
    }
});


            map.addSource('Sedes', {
                'type': 'vector',
                'url': 'mapbox://siepj.b8sktxeo'
            });

            // Agregar una capa (layer) utilizando la fuente añadida
            map.addLayer({
                'id': 'capa_sedes',
                'type': 'symbol', // o 'line', 'symbol', 'circle', etc., dependiendo del tipo de capa
                'source': 'Sedes',
                'source-layer': 'sede2023_v2-abyaeh', // Reemplaza con el nombre de la capa en el tileset
				/*'layout': {
                    'visibility': 'none' 
                },*/
                'paint': {
                   'fill-color': '#fff', // Color inicial de la capa
                    'fill-opacity': 1
                }
            });	
			
/*
map.on('idle', function() {
            if (map.getLayer('capa_sedes') && map.isSourceLoaded('Sedes')) {
                // Obtener los datos de la fuente 'Sedes'
                var features = map.querySourceFeatures('Sedes', {
                    sourceLayer: 'sede2023_v2-abyaeh'
                });

                // Iterar sobre cada feature para crear un marcador y un popup
                features.forEach(function(feature) {
                    var coordinates = feature.geometry.coordinates;
                    var nombre = feature.properties.nombre;
                    var direccion = feature.properties.direccion;

                    // Crear un popup para cada sede
                    var popup = new mapboxgl.Popup({ offset: 25 })
                        .setText(`${nombre}\n${direccion}`);

                    // Crear un marcador para cada sede
                    new mapboxgl.Marker()
                        .setLngLat(coordinates)
                        .setPopup(popup)
                        .addTo(map);
                });
            }
        });
   

*/

function makePopupDraggable(popup) {
    var pos = { top: 0, left: 0, x: 0, y: 0 };

    const onMouseMove = function(e) {
        const dx = e.clientX - pos.x;
        const dy = e.clientY - pos.y;

        pos.top = pos.top + dy;
        pos.left = pos.left + dx;
        pos.x = e.clientX;
        pos.y = e.clientY;

        popup._content.style.top = pos.top + 'px';
        popup._content.style.left = pos.left + 'px';
    };

    const onMouseUp = function() {
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
    };

    const onMouseDown = function(e) {
        pos = {
            left: popup._content.offsetLeft,
            top: popup._content.offsetTop,
            // Guardar la posición inicial del cursor
            x: e.clientX,
            y: e.clientY,
        };

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    };

    var titleBar = popup._content.querySelector('.popup-title-bar');
    if (titleBar) {
        titleBar.addEventListener('mousedown', onMouseDown);
    }
}

// Luego de crear el popup, llama a esta función
//makePopupDraggable(popup);


    function crearMarcadores() {
        if (!marcadoresCreados) {
            var features = map.querySourceFeatures('Sedes', {
                sourceLayer: 'sede2023_v2-abyaeh'
            });

            features.forEach(function(feature) {
                var coordinates = feature.geometry.coordinates;
                var nombre = feature.properties.nombre;
                var direccion = feature.properties.direccion;
                var departamentoSede = feature.properties.x_corte; // Asumiendo que 'x_corte' es el departamento

				var googleMapsUrl = 'https://www.google.com/maps?q=' + coordinates[1] + ',' + coordinates[0] + '&z=17&output=embed';
				
				
   var popupContent = '<div class="popup-title-bar">' +
        '<h3>' + nombre + '</h3>' +
        '<div>' +
            '<iframe frameborder="0" style="border:0; width: 100%; height: 330px;" src="' + googleMapsUrl + '" allowfullscreen></iframe>' +
        '</div>' +
        '<p>' + direccion + '</p>' +
        '</div>';				

				//var popupContent = '<strong>' + nombre + '</strong><p>' + direccion + '</p>';
				//var popup = new mapboxgl.Popup({ offset: 25 }).setHTML(popupContent);
				
				var popup = new mapboxgl.Popup({ offset: 25, className: 'draggable-popup' })
					.setHTML(popupContent);

                var marker = new mapboxgl.Marker()
                    .setLngLat(coordinates)
                    .setPopup(popup)
                    .addTo(map);

                // Guardar el marcador y el departamento asociado
                todosLosMarcadores.push({ marker, departamento: departamentoSede });
				makePopupDraggable(popup);
            });

            marcadoresCreados = true;
			filtrarMarcadoresPorDepartamento("x");
        }
    }
	
	


    map.on('idle', function() {
        if (map.getLayer('capa_sedes') && map.isSourceLoaded('Sedes')) {
		map.setLayoutProperty('capa_sedes', 'visibility', 'visible');
            crearMarcadores();
			
        }
    });

    // Función para mostrar/ocultar marcadores basado en el departamento
    function filtrarMarcadoresPorDepartamento(departamento) {
        todosLosMarcadores.forEach(function(obj) {
            if (departamento === "" || obj.departamento === departamento) {
			//map.setLayoutProperty('capa_sedes', 'visibility', 'visible')
                obj.marker.getElement().style.display = 'block';
            } else {
                obj.marker.getElement().style.display = 'none';
				//map.setLayoutProperty('capa_sedes', 'visibility', 'none')
            }
        });
    }


					 map.setLayoutProperty('mi-capa', 'visibility', 'visible'); // Mostrar capa de provincias
					 map.setLayoutProperty('nombre_dj', 'visibility', 'visible'); // Mostrar capa de provincias
					 map.setLayoutProperty('bordes-departamento', 'visibility', 'visible'); // Mostrar capa de provincias
					 map.setLayoutProperty('capa_provincia', 'visibility', 'none'); // Mostrar capa de provincias
					 map.setLayoutProperty('bordes-provincia', 'visibility', 'none'); // Mostrar capa de provincias
					 map.setLayoutProperty('nombre_prov', 'visibility', 'none'); // Mostrar capa de provincias
					// map.setLayoutProperty('capa_sedes', 'visibility', 'none'); // Mostrar capa de provincias
					// filtrarMarcadoresPorDepartamento("");
					//map.setFilter('capa_sedes', null);
		
            // Llenar el combobox con los nombres de los departamentos
            const select = document.getElementById('departmentSelect');
            for (const name in departments) {
                const option = document.createElement('option');
                option.value = name;
                option.textContent = name;
                select.appendChild(option);
            }

            select.addEventListener('change', function() {
			var departamentoSeleccionado = this.value;
                if (departamentoSeleccionado === "") {
                    // Restaurar vista inicial del mapa
                    map.flyTo({
                        center: [-75.015152, -9.189967],
                        zoom: 5
                    });
					
                    map.setPaintProperty('mi-capa', 'fill-color', [
                        'match',
                        ['get', 'DISTRITO_J'],
						'AMAZONAS','#B12009',
						'ANCASH','#B12009',
						'APURIMAC','#B12009',
						'AREQUIPA','#B12009',
						'AYACUCHO','#B12009',
						'CAJAMARCA','#B12009',
						'CALLAO','#B12009',
						//'CAÑETE','#B12009',
						'CUSCO','#B12009',
						//'HUANCAVELICA','#B12009',
						//'HUANUCO','#B12009',
						//'HUAURA','#B12009',
						//'ICA','#B12009',
						//'JUNIN','#B12009',
						'LA LIBERTAD','#B12009',
						'LAMBAYEQUE','#B12009',
						//'LIMA ESTE','#B12009',
						//'LIMA NORTE','#B12009',
						//'LIMA SUR','#B12009',
						//'LIMA','#B12009',
						'LORETO','#B12009',
						'MADRE DE DIOS','#B12009',
						'MOQUEGUA','#B12009',
						//'PASCO','#B12009',
						'PIURA','#B12009',
						'PUENTE PIEDRA-VENTANILLA','#B12009',
						'PUNO','#B12009',
						'SAN MARTIN','#B12009',
						'SANTA','#B12009',
						//'SELVA CENTRAL','#B12009',
						'SULLANA','#B12009',
						'TACNA','#B12009',
						'TUMBES','#B12009',
						//'UCAYALI','#B12009', 
                        '#fff' 
                    ]);					
					
					
					map.setPaintProperty('bordes-departamento', 'line-width', 1);
                     map.setPaintProperty('mi-capa', 'fill-opacity',1);
					 map.setLayoutProperty('mi-capa', 'visibility', 'visible'); // Mostrar capa de provincias
					 map.setLayoutProperty('nombre_dj', 'visibility', 'visible'); // Mostrar capa de provincias
					 map.setLayoutProperty('bordes-departamento', 'visibility', 'visible'); // Mostrar capa de provincias
					 map.setLayoutProperty('capa_provincia', 'visibility', 'none'); // Mostrar capa de provincias
					 map.setLayoutProperty('bordes-provincia', 'visibility', 'none'); // Mostrar capa de provincias
					 map.setLayoutProperty('nombre_prov', 'visibility', 'none'); // Mostrar capa de provincias
					// map.setLayoutProperty('capa_sedes', 'visibility', 'none'); // Mostrar capa de provincias
					 // filtrarMarcadoresPorDepartamento(departamentoSeleccionado); 
					 //map.setFilter('capa_sedes', null);
					filtrarMarcadoresPorDepartamento("x");
					
                } else if (departments[this.value]) {
				
				
				const department = departments[this.value];
                    map.flyTo({
                        center: department.center,
                        zoom: department.zoom
                    });
					 
					//map.setFilter('capa_sedes', ['==', ['get', 'x_corte'], department]);
                    // Cambiar el color del departamento seleccionado
                    map.setPaintProperty('mi-capa', 'fill-color', [
                        'match',
                        ['get', 'DISTRITO_J'],
                        this.value, '#B12009', 
                        '#fff' 
                    ]);
					
                    /*map.setPaintProperty('mi-capa', 'fill-opacity', [
                        'match',
                        ['get', 'DISTRITO_J'],
                        this.value, 0.3,1 
                    ]);
					*/
					 map.setPaintProperty('bordes-departamento', 'line-width', [
                        'match',
                        ['get', 'DISTRITO_J'],
                        this.value, 5,1
                    ]);
					
					
					
					 map.setPaintProperty('mi-capa', 'fill-opacity',0.5);
					 map.setLayoutProperty('mi-capa', 'visibility', 'visible'); // Mostrar capa de provincias
					 map.setLayoutProperty('nombre_dj', 'visibility', 'visible'); // Mostrar capa de provincias
					 map.setLayoutProperty('bordes-departamento', 'visibility', 'visible'); // Mostrar capa de provincias
					 map.setLayoutProperty('capa_provincia', 'visibility', 'visible'); // Mostrar capa de provincias
					 map.setLayoutProperty('bordes-provincia', 'visibility', 'visible'); // Mostrar capa de provincias
					 map.setLayoutProperty('nombre_prov', 'visibility', 'visible'); // Mostrar capa de provincias
					 map.setLayoutProperty('capa_sedes', 'visibility', 'visible'); // Mostrar capa de provincias
					 filtrarMarcadoresPorDepartamento(departamentoSeleccionado);
                }
            });
        });	
		

		 
	
	